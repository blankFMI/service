#!/bin/bash -e

cd ..
./gradlew clean build test
cd scripts
